function setup() {
  createCanvas(400, 400);
  background(135, 206, 235); // Céu azul claro
  
  // Desenhando o solo (campo)
  fill(34, 139, 34); // Cor do campo (verde)
  rect(0, height - 100, width, 100); // Solo

  // Desenhando uma árvore no fundo
  drawTree(80, height - 120);

  // Desenhando o agricultor
  drawFarmer(width / 2, height - 180);
}

function drawTree(x, y) {
  // Tronco da árvore
  fill(139, 69, 19); // Cor do tronco (marrom)
  rect(x, y, 20, 60);
  
  // Folhagem da árvore
  fill(0, 128, 0); // Cor das folhas (verde)
  ellipse(x - 20, y - 20, 60, 60);
  ellipse(x + 20, y - 20, 60, 60);
  ellipse(x, y - 40, 60, 60);
}

function drawFarmer(x, y) {
  // Corpo do agricultor (um círculo para simplificar)
  fill(255, 204, 0); // Cor da pele
  ellipse(x, y, 30, 30); // Cabeça
  
  // Corpo
  fill(0, 0, 255); // Cor do corpo (azul)
  rect(x - 10, y + 15, 20, 50); // Corpo

  // Braços
  stroke(0);
  strokeWeight(5);
  line(x - 15, y + 25, x - 30, y + 45); // Braço esquerdo
  line(x + 15, y + 25, x + 30, y + 45); // Braço direito
  
  // Pernas
  line(x - 10, y + 65, x - 20, y + 90); // Perna esquerda
  line(x + 10, y + 65, x + 20, y + 90); // Perna direita
  
  // Chapéu
  fill(139, 69, 19); // Cor do chapéu (marrom)
  arc(x, y - 15, 40, 30, PI, 0, CHORD); // Chapéu

  // Ferramenta (enxada) - apenas uma linha simples representando
  stroke(139, 69, 19); // Cor da ferramenta (marrom)
  line(x + 30, y + 45, x + 70, y + 60); // Cabo da enxada
  line(x + 70, y + 60, x + 80, y + 40); // Lâmina da enxada
}
